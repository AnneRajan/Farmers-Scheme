import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Bidding } from './bidding';


@Injectable({
  providedIn: 'root'
})
export class BiddingService {
  private baseURL = "http://localhost:2023/farmer/getcrop";


  constructor(private httpClient : HttpClient) { }
  getCropList() : Observable<Bidding[]>{
    return this.httpClient.get<Bidding[]>(`${this.baseURL}`);
  }
  getCropById(cropid: number): Observable<Bidding>{
    return this.httpClient.get<Bidding>(`${this.baseURL}/${cropid}`);
  }

}
