import { Bidding } from './bidding';

describe('Bidding', () => {
  it('should create an instance', () => {
    expect(new Bidding()).toBeTruthy();
  });
});
