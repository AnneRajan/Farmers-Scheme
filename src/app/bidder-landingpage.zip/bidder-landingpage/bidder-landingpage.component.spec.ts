import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BidderLandingpageComponent } from './bidder-landingpage.component';

describe('BidderLandingpageComponent', () => {
  let component: BidderLandingpageComponent;
  let fixture: ComponentFixture<BidderLandingpageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BidderLandingpageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BidderLandingpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
