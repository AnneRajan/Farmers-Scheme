package com.lti.dao;

import com.lti.model.ApplyInsurance;

public interface ApplyInsuranceImp {
	ApplyInsurance applyInsuranceCreation(ApplyInsurance applyinsurance);

}
