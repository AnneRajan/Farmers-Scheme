import { Component, OnInit,OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Bidding } from '../bidding';
import { BiddingService } from '../bidding.service';
import { Subscription, interval } from 'rxjs';
@Component({
  selector: 'app-crop-details',
  templateUrl: './crop-details.component.html',
  styleUrls: ['./crop-details.component.css']
})
export class CropDetailsComponent implements OnInit,OnDestroy {
  subscription: Subscription
cropid:number
bidding : Bidding

public dateNow = new Date();
    public dDay = new Date('Dec 17 2020 00:00:00');
    milliSecondsInASecond = 1000;
    hoursInADay = 24;
    minutesInAnHour = 60;
    SecondsInAMinute  = 60;

    public timeDifference;
    public secondsToDday;
    public minutesToDday;
    public hoursToDday;
    public daysToDday;

    private getTimeDifference () {
      this.timeDifference = this.dDay.getTime() - new  Date().getTime();
      this.allocateTimeUnits(this.timeDifference);
  }
  private allocateTimeUnits (timeDifference) {
    this.secondsToDday = Math.floor((timeDifference) / (this.milliSecondsInASecond) % this.SecondsInAMinute);
    this.minutesToDday = Math.floor((timeDifference) / (this.milliSecondsInASecond * this.minutesInAnHour) % this.SecondsInAMinute);
    this.hoursToDday = Math.floor((timeDifference) / (this.milliSecondsInASecond * this.minutesInAnHour * this.SecondsInAMinute) % this.hoursInADay);
    this.daysToDday = Math.floor((timeDifference) / (this.milliSecondsInASecond * this.minutesInAnHour * this.SecondsInAMinute * this.hoursInADay));
}


  constructor(private route: ActivatedRoute, private biddingService : BiddingService) { }

  ngOnInit(): void {
    this.cropid = this.route.snapshot.params['cropid'];

    this.bidding = new Bidding();
    this.biddingService.getCropById(this.cropid).subscribe(data =>{
      this.bidding = data;
      
    })
    this.subscription = interval(1000)
    .subscribe(x => { this.getTimeDifference();});
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
}


}
