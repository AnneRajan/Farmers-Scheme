export class Admin {
    admin_uname:string;
    admin_pwd:string;
     constructor(admin_uname : string, admin_pwd : string){
        this.admin_uname = admin_uname;
        this.admin_pwd=admin_pwd;
    }    

}
