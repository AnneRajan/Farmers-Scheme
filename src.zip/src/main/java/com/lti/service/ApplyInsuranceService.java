package com.lti.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.ApplyInsuranceDao;
import com.lti.model.ApplyInsurance;

@Service
@Transactional
public class ApplyInsuranceService {
	
	@Autowired
	ApplyInsuranceDao dao;
	
	public ApplyInsurance ApplyInsuranceCreation(ApplyInsurance applyinsurance) {
		return dao.applyInsuranceCreation(applyinsurance);
	}

}
