import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-insurance-approval',
  templateUrl: './insurance-approval.component.html',
  styleUrls: ['./insurance-approval.component.css']
})
export class InsuranceApprovalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
