import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyserviceService } from '../myservce.Service';
import { AuthenticationService } from '../service/authentication.service';

@Component({
  selector: 'app-bidder-landingpage',
  templateUrl: './bidder-landingpage.component.html',
  styleUrls: ['./bidder-landingpage.component.css']
})
export class BidderLandingpageComponent implements OnInit {
  biddrdetail=sessionStorage.getItem('farmeremailid');
  message:string;
  constructor(private myservice:MyserviceService, private router:Router, private authservice:AuthenticationService) { }

  ngOnInit(): void {
    this.myservice.checkstatus(this.biddrdetail).subscribe(
      data=>{
        this.message=data;
        if(this.message==="Admin approval is still pending"){
          alert("Admin approval is still pending.... Check after Sometime")
          this.authservice.logOut();
          this.router.navigate(['/index']);
        }
      })
  }

}
