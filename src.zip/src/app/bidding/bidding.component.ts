import { Component, OnInit } from '@angular/core';
import {Bidding} from '../bidding';
import { BiddingService } from '../bidding.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-bidding',
  templateUrl: './bidding.component.html',
  styleUrls: ['./bidding.component.css']
})
export class BiddingComponent implements OnInit {
  biddings : Bidding[];

  constructor(private biddingService : BiddingService, private router: Router) { }

  ngOnInit(): void {
 this.getCrops();
  }
  private getCrops(){
    this.biddingService.getCropList().subscribe(data =>{
      this.biddings=data;
    });
  }

  viewCropDetails(cropid:number){
    this.router.navigate(['crop-details',cropid]);
  }

}
