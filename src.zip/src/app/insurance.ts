export class Insurance {
    policy_no: number;
    crop_type: String;
    area: number;
    policy_for: String;
    state: String;
    district: String; 
    insurance_company: String;
    premiumamt: number;
    sum_insured:number;
}
