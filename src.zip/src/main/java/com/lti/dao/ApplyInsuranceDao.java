package com.lti.dao;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import com.lti.model.ApplyInsurance;
@Repository
public class ApplyInsuranceDao implements ApplyInsuranceImp{

	@PersistenceContext	
	 EntityManager em;
	@Override
	public ApplyInsurance applyInsuranceCreation(ApplyInsurance applyinsurance) {
		ApplyInsurance a = em.merge(applyinsurance);
		return a;
	}

}
