export class Bidding {
        cropid: number;
        crop_name:string;
        crop_type: string;
        base_price: number;
        current_bid: number;
        
}
