package com.lti.dao;

import com.lti.model.Crop;

public interface CropDaoImp {
	
	Crop placesellrequest(Crop c);
	

}
