import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewsoldhistory',
  templateUrl: './viewsoldhistory.component.html',
  styleUrls: ['./viewsoldhistory.component.css']
})
export class ViewsoldhistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
