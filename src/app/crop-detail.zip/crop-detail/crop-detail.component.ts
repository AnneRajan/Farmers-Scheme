import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crop-detail',
  templateUrl: './crop-detail.component.html',
  styleUrls: ['./crop-detail.component.css']
})
export class CropDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
