package com.lti.dao;

import com.lti.model.ClaimInsurance;

public interface ClaimInsuranceImp {
	ClaimInsurance claimInsuranceCreation(ClaimInsurance claiminsurance);
}
