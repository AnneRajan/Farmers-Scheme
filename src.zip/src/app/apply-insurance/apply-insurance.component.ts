import { Component, OnInit } from '@angular/core';
import { Insurance } from '../insurance';
import { InsuranceService } from '../insurance.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-apply-insurance',
  templateUrl: './apply-insurance.component.html',
  styleUrls: ['./apply-insurance.component.css']
})
export class ApplyInsuranceComponent implements OnInit {
insurance: Insurance = new Insurance();
  constructor(private insuranceService: InsuranceService,
    private router: Router) { }

  ngOnInit(): void {
  }
  saveInsurance(){
    this.insuranceService.createInsurance(this.insurance).subscribe( data =>{
      console.log(data);
    
    },
    error => console.log(error));
  }
  onSubmit(){
    console.log(this.insurance);
    this.saveInsurance();
  }
}
