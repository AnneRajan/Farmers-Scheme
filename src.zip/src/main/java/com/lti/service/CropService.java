package com.lti.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.CropDaoClass;
import com.lti.model.Crop;
import com.lti.model.FarmerRegisteration;

@Service
@Transactional
public class CropService {
	@Autowired
	CropDaoClass cropdao;
	
	public Crop placesellrequest(Crop c) {
		return cropdao.placesellrequest(c);
	}	
	
	

}
