package com.lti.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceUnit;

import org.springframework.stereotype.Repository;

import com.lti.model.Crop;
import com.lti.model.FarmerRegisteration;

@Repository
public class CropDaoClass implements CropDaoImp {
	@PersistenceContext
	EntityManager em;
	
	


	public Crop placesellrequest(Crop c) {
		Crop crop =em.merge(c);
		return crop;
	}




	

}
