package com.lti.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.lti.model.ClaimInsurance;

@Repository
public class ClaimInsuranceDao implements ClaimInsuranceImp {

	@PersistenceContext	
	 EntityManager em;
	
	@Override
	public ClaimInsurance claimInsuranceCreation(ClaimInsurance claiminsurance) {
		ClaimInsurance c = em.merge(claiminsurance);
		return c;
	}
}
